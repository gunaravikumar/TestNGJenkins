Driver updates:
	This firefox driver supports upto firefox Version  ≥79.

If you latest firefox driver please upgrade it.