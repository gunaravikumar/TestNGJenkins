1. Enter IP details in GridSetupDetails.txt file.

2. Update Browser drivers according to the browser version.

3. Please verify supported version of browser in readme file under Browser drivers folder.

